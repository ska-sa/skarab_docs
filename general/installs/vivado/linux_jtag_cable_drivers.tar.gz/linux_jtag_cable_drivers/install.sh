echo "Copying firmware to /usr/share:"

for fw in xusb*.hex; do
    $ASROOT cp -v "$fw" "/usr/share/"
done

echo "Installing udev rules:"
$ASROOT bash -c "sed -e 's/TEMPNODE/tempnode/' -e 's/SYSFS/ATTRS/g' -e 's/BUS/SUBSYSTEMS/' \"xusbdfwu.rules\" >/etc/udev/rules.d/xusbdfwu.rules"
echo "Done!"
